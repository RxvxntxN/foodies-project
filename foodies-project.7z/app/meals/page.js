import React from 'react'

export default function Meals() {
  return (
    <h1>Some Meals and Eating</h1>
  )
}