import React from 'react'

function Gamings() {
  return (
    <h1>Some gaming blogs</h1>
  )
}

export default Gamings